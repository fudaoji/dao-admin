<?php

$plugin = get_plugin_name(__FILE__);

return [
    'type' => '__PLUGIN_TYPE__',
    'title' => '__PLUGIN_TITLE__',
    'name' => $plugin,
    'desc' => '__PLUGIN_DESC__',
    'version' => '__PLUGIN_VERSION__',
    'author' => '__PLUGIN_AUTHOR__',
    'logo' => '__PLUGIN_LOGO__',
    'admin_url' => '/app/'.$plugin.'/admin',
    'admin_url_type' => 1,
    'tenant_url' => '/app/'.$plugin.'/tenant',
    'tenant_url_type' => 1
];
