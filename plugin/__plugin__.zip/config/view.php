<?php

use support\view\ThinkPHP;

return [
    'handler' => ThinkPHP::class,
    'options' => [
        // 视图中使用的常量，需要自定义时可放开
        'tpl_replace_string'  =>  [
            '__STATIC__' => '/static',
            '__LIB__' => '/static/libs',
            '__CSS__' => '/static/css',
            '__JS__' => '/static/js',
            '__IMG__' => '/static/imgs'
            /*'__STATIC__' => $static_path,
            '__LIB__' => $static_path . '/libs',
            '__CSS__' => $static_path . '/css',
            '__JS__' => $static_path . '/js',
            '__IMG__' => $static_path . '/imgs'*/
        ],
        //自定义标签
        'taglib_pre_load'    => implode(',', include __DIR__ . '/taglib.php'),
    ],
];
