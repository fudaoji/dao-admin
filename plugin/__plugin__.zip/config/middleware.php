<?php

return [
    'admin' => [
        \plugin\__PLUGIN_NAME__\app\admin\middleware\CheckAuth::class,
    ],
    'tenant' => [
        \app\common\middleware\PluginCheck::class,
        \plugin\__PLUGIN_NAME__\app\tenant\middleware\CheckAuth::class,
    ],
];
