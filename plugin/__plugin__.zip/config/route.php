<?php

use Webman\Route;

$plugin = get_plugin_name(__FILE__);

Route::group('/app/'.$plugin, function () use ($plugin) {
    Route::any('/', function () use ($plugin) {
        return redirect('/app/' . $plugin . '/' . config('plugin.' . $plugin . '.app.default_app'));
    });
});

Route::fallback(function ($request) use($plugin) {
    if ($request->expectsJson()) {
        return json(['code' => 404, 'msg' => '404 not found']);
    }
    return view(config("plugin.{$plugin}.app.404_tpl"), []);
});