<?php
/**
 * Created by PhpStorm.
 * Script Name: menu.php
 * Create: 12/17/22 10:24 AM
 * Description: 功能菜单
 * Author: fudaoji<fdj@kuryun.cn>
 */

$plugin = get_plugin_name(__FILE__);

$admin_prefix = '/app/'.$plugin.'/admin/';
$tenant_prefix = '/app/'.$plugin.'/tenant/';

return [
    'admin' => [
        ['title' => '首页', 'node' => 'index/welcome'],
    ],
    'tenant' => [
        ['title' => '首页', 'node' => 'index/welcome'],
    ]
];