<?php

$plugin = get_plugin_name(__FILE__);
return [
    'files' => [
        base_path() . '/plugin/'.$plugin.'/app/functions.php',
    ]
];