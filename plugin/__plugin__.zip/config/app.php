<?php

return [
    'controller_suffix' => '',
    'controller_reuse' => true,

    // 默认应用
    'default_app' => 'tenant',

    'dispatch_error'   => app_path() . '/common/view/common/jump.html',
    'dispatch_success' => app_path() . '/common/view/common/jump.html',
    'exception_tpl'    => app_path() . '/common/view/error/500.html',
    '404_tpl'    => app_path() . '/common/view/error/404.html',
    'error_message'    => '页面错误！请稍后再试～',
];
