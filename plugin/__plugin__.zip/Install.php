<?php

namespace plugin\__PLUGIN_NAME__;

class Install
{
    /**
     * 安装
     *
     * @param $version
     * @return void
     */
    public static function install($version = '')
    {
        //todo
    }

    /**
     * 卸载
     *
     * @param $version
     * @return void
     */
    public static function uninstall($version = '')
    {
        //todo
    }

    /**
     * 更新
     *
     * @param $from_version
     * @param $to_version
     * @param $context
     * @return void
     */
    public static function update($from_version, $to_version, $context = null)
    {
        //todo
    }
}