<?php
/**
 * Created by PhpStorm.
 * Script Name: Base.php
 * Create: 2022/12/22 11:04
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace plugin\__PLUGIN_NAME__\app\model;

use app\BaseModel;

class Base extends BaseModel
{
    public function __construct($data = [])
    {
        $this->table = $this->getTablePrefix() . '__PLUGIN_NAME___'.$this->table;
        parent::__construct($data);
    }
}