<?php
/**
 * Created by PhpStorm.
 * Script Name: Bot.php
 * Create: 2023/3/30 9:43
 * Description: 个微消息事件处理器
 * Author: fudaoji<fdj@kuryun.cn>
 */
namespace plugin\__PLUGIN_NAME__\app\platform\controller;

use plugin\wechat\app\bot\controller\Addon;

class Bot extends Addon
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 私聊处理器
     * @return bool
     * @throws \Psr\SimpleCache\InvalidArgumentException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     * Author: fudaoji<fdj@kuryun.cn>
     */
    public function privateChatHandle(){

    }

    /**
     * 群聊处理器
     * @throws \Psr\SimpleCache\InvalidArgumentException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function groupChatHandle(){

    }

    //其他事件处理器...
}