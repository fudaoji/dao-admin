<?php
/**
 * Created by PhpStorm.
 * Script Name: Mp.php
 * Create: 2023/1/17 10:34
 * Description: 公众号自动回复演示
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace plugin\__PLUGIN_NAME__\app\platform\controller;

use app\PluginController;
use EasyWeChat\Kernel\Messages\Text;

class Mp extends PluginController
{

    /**
     * 公众号消息处理器
     * @param $message
     * @return Text
     * Author: fudaoji<fdj@kuryun.cn>
     */
    public function message($message){
        return new Text("I am from an app, I had received your message “" . $message['Content'] . '”！');
    }
}