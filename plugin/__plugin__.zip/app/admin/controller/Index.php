<?php
/**
 * Created by PhpStorm.
 * Script Name: Index.php
 * Create: 2023/7/25 10:09
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace plugin\__PLUGIN_NAME__\app\admin\controller;


use plugin\__PLUGIN_NAME__\app\AdminController;

class Index extends AdminController
{
    public function index(){
        return $this->show();
    }

    public function welcome(){
        return $this->show();
    }

}