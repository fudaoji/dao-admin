<?php
/**
 * Created by PhpStorm.
 * Script Name: FormBuilder.php
 * Create: 9/21/22 11:11 PM
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace plugin\__PLUGIN_NAME__\app\tenant\controller;


class FormBuilder extends \app\common\controller\FormBuilder
{

}