<?php
/**
 * Created by PhpStorm.
 * Script Name: Uploader.php
 * Create: 2022/12/19 18:01
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace plugin\__PLUGIN_NAME__\app\tenant\controller;


class Uploader extends \app\tenant\controller\Uploader
{

}