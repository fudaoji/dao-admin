<?php
/**
 * Created by PhpStorm.
 * Script Name: ListBuilder.php
 * Create: 9/21/22 11:09 PM
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace plugin\__PLUGIN_NAME__\app\tenant\controller;

use app\tenant\service\Auth;
use plugin\__PLUGIN_NAME__\app\tenant\service\Auth as AppAuth;

class ListBuilder extends \app\common\controller\ListBuilder
{
    public function __construct()
    {
        parent::__construct();
        $this->setAuth(['super' => Auth::isSuperAdmin(), 'auth_list' => AppAuth::getAuthList()]);
    }
}