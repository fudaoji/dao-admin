<?php

namespace plugin\__PLUGIN_NAME__\app\tenant\controller;

use app\PluginController;
use plugin\__PLUGIN_NAME__\app\TenantController;

class Index extends TenantController
{

    public function index()
    {
        return $this->show();
    }

    public function welcome()
    {
        return $this->show();
    }
}
