<?php
/**
 * Created by PhpStorm.
 * Script Name: Auth.php
 * Create: 12/17/22 11:42 AM
 * Description:
 * Author: fudaoji<fdj@kuryun.cn>
 */

namespace plugin\__PLUGIN_NAME__\app\tenant\service;


class Auth
{

    /**
     * 获取员工在当前应用中的权限
     * Author: fudaoji<fdj@kuryun.cn>
     */
    public static function getAuthList(){
        //todo
        return [];
    }
}